$('.indicator').on('click', function (e) {
    e.preventDefault();
    var current = $('.slide-active').data('slide');
    var next = $(this).data('slide');
    $('.indicator').removeClass('active');
    $(this).addClass('active');
    if (current === next) {
        return false;
    } else {
        $('.carousel').find('.slides[data-slide=' + next + ']').addClass('slide-prestart');
        $('.slide-active').addClass('end-animation');
        setTimeout(function () {
            $('.slide-prestart').removeClass('start-animation slide-prestart').addClass('slide-active');
            $('.end-animation').addClass('start-animation').removeClass('end-animation slide-active');
        }, 1000);
    }
});